const fs = require("fs");

// const textDir = (root:string,page:number,dataLength:number) => {
//   let text = "<div>";
//   let data:string[] = fs.readdirSync(root, "ascii");
//   let index = page*10
//   let plus = (dataLength)%10
//   if(index<dataLength){
//     if(index<=dataLength-10){
//       plus = 10
//     }
//     for(let i=index; i<index+plus; i++){
//       text += `
//       <a href=/post/${data[i]}>
//       <p>${data[i].slice(0,-4)}</p>
//       </a>
//     `;
//     }
//   } else {
//     text += '<p>빈 페이지입니다</p>'
//   }
//   text += "</div>"
//   return text;
// };
// * text파일 목록 HTML

// const listLength = (page:number)=>{
//   let text = '<ul id="list">'
//   for(let i=0;i<=page;i++){
//     text += `<a href=/list/${i}><li>${i+1}</li></a>`
//   }
//   text += '</ul>'
//   return text
// }
// * text파일 목록 버튼 HTML

// const dirArr = (root:string) => {
//   let data:string[] = fs.readdirSync(root, "ascii");
//   data = data.map((fileName) => {
//     return "/" + fileName;
//   });
//   return data;
// };
// * text파일 목록 배열

interface data {
  title:string;
  description:string;
  time:string;
}

const getJSON = (link:string) => {
  const dataBuffer = fs.readFileSync(link)
  const dataJSON = dataBuffer.toString()
  const data = JSON.parse(dataJSON)
  return data
}

const makeList = (root:data[],page:number) => {
  let start = page*10
  let end
  if(root.length >= start+10){
    end = 10
  } else {
    end = root.length%10
  }
  let text = '<div style="height:300px">'
  for(let i=start ;i<start+end; i++){
    text += `
      <a href=/post/${root[i]['title']}>
      <p>${root[i]['title']}</p>
      </a>
    `;
  }
  return text+'</div>'
}

const listButton = (page:number) => {
  let length = Math.floor((page-1)/10)+1
  let text = '<div style="display:flex">'
  for(let i=0; i<length;i++){
    text += `<a href=/list/${i}><p>${i}</p></a>`
  }
  text += '</div>'
  return text
}

const file = (fileName:string) => {
  let text = fs.readFileSync(fileName, "utf8");
  return text;
};
// * 파일 불러오기

module.exports = function (url:string,key:string) {
  let data = getJSON('data.json');
  let html = "<!DOCTYPE html>";
  html += file("./head.txt");
  html += file("./content/header.txt");
  if(url === 'list') {
    html += makeList(data,Number(key))
    html += listButton(data.length)
  } else if(url === 'posting') {
    html += file("./content/main.txt");
  } else if(url === 'post') {
    data.map((item)=>{
      if(item.title === key){
        html+= `<h2>제목 : ${item.title}</h2>`
        html+= `<h4>내용 : ${item.description}</h4>`
        html+= `<h6>작성일 : ${item.time}</h6>`
      }
    })
  }
  html += file("./content/footer.txt");
  return html;
  // html 파일 만들기
};
