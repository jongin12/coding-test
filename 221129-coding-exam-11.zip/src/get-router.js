module.exports = function (getUrl) {
    // stringOnlyArray.forEach((element) => {
    //   if (typeof element !== "string") {
    //     console.error("파일이름이어야 하므로 모두 문자열이여야 합니다.", element);
    //   }
    // });
    console.log("받은 get.url", getUrl);
    // console.log("받은 text Array", stringOnlyArray);
};
