var fs = require("fs");
var getJSON = function (link) {
    var dataBuffer = fs.readFileSync(link);
    var dataJSON = dataBuffer.toString();
    var data = JSON.parse(dataJSON);
    return data;
};
var makeList = function (root, page) {
    var start = page * 10;
    var end;
    if (root.length >= start + 10) {
        end = 10;
    }
    else {
        end = root.length % 10;
    }
    var text = '<div style="height:300px">';
    for (var i = start; i < start + end; i++) {
        text += "\n      <a href=/post/".concat(root[i]['title'], ">\n      <p>").concat(root[i]['title'], "</p>\n      </a>\n    ");
    }
    return text + '</div>';
};
var listButton = function (page) {
    var length = Math.floor((page - 1) / 10) + 1;
    var text = '<div style="display:flex">';
    for (var i = 0; i < length; i++) {
        text += "<a href=/list/".concat(i, "><p>").concat(i, "</p></a>");
    }
    text += '</div>';
    return text;
};
var file = function (fileName) {
    var text = fs.readFileSync(fileName, "utf8");
    return text;
};
// * 파일 불러오기
module.exports = function (url, key) {
    var data = getJSON('data.json');
    var html = "<!DOCTYPE html>";
    html += file("./head.txt");
    html += file("./content/header.txt");
    if (url === 'list') {
        html += makeList(data, Number(key));
        html += listButton(data.length);
    }
    else if (url === 'posting') {
        html += file("./content/main.txt");
    }
    else if (url === 'post') {
        data.map(function (item) {
            if (item.title === key) {
                html += "<h2>\uC81C\uBAA9 : ".concat(item.title, "</h2>");
                html += "<h4>\uB0B4\uC6A9 : ".concat(item.description, "</h4>");
                html += "<h6>\uC791\uC131\uC77C : ".concat(item.time, "</h6>");
            }
        });
    }
    html += file("./content/footer.txt");
    return html;
    // html 파일 만들기
};
