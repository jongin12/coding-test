var http = require("http");
var qs = require("querystring");
var fs2 = require("fs");
var getRouter = require("./src/get-router");
var domMaker = require("./src/dom-maker");
var server = http.createServer(function (req, res) {
    var getMethod = req.method;
    switch (getMethod) {
        case "GET":
            var getUrl = req.url;
            if (getUrl !== "/favicon.ico") {
                // * getRouter 출력결과 두번이 일어나는 것을 확인함
                // * 슬래쉬, 파비콘 두개라 두번 트랜잭션이 발생
                // * if 제어로 간단하게 해결할 수 있게 될 것
                // * /favicon.ico는 무시하게끔 만들던지, 파비콘 하나 설정해주면 될듯
                // ! /favicon.ico 요청은 무시하도록 설정함.
                // console.log(process.memoryUsage());
                if (getUrl.endsWith(".css")) {
                    var css = fs2.readFileSync('.' + getUrl, "utf8");
                    res.writeHead(200, { "Content-Type": "text/css" });
                    res.end(css);
                }
                else if (getUrl.startsWith("/list/")) {
                    getRouter(getUrl);
                    var number = getUrl.split("/")[2];
                    res.writeHead(200, { "Content-Type": "text/html" });
                    res.write(domMaker("list", number));
                    res.end();
                }
                else if (getUrl.startsWith("/posting")) {
                    getRouter(getUrl);
                    var str = getUrl.split("/")[2];
                    res.writeHead(200, { "Content-Type": "text/html" });
                    res.write(domMaker("posting", str));
                    res.end();
                }
                else if (getUrl.startsWith("/post/")) {
                    getRouter(getUrl);
                    var str = getUrl.split("/")[2];
                    res.writeHead(200, { "Content-Type": "text/html" });
                    res.write(domMaker("post", str));
                    res.end();
                }
                else {
                    res.writeHead(404, { "Content-Type": "text/html" });
                    res.write("404 error");
                    res.end();
                }
            }
            break;
        case "POST":
            // console.log("hello post");
            var body_1 = '';
            req.on("data", function (data) {
                body_1 += data;
            });
            req.on("end", function () {
                body_1 = qs.parse(body_1);
                body_1.time = new Date();
                // console.log(body)
                var dataBuffer = fs2.readFileSync('data.json');
                var dataJSON = dataBuffer.toString();
                var data = JSON.parse(dataJSON);
                data.push(body_1);
                var bodyJson = JSON.stringify(data);
                fs2.writeFileSync('data.json', bodyJson);
                res.writeHead(302, {
                    Location: "http://127.0.0.1:3333/post/".concat(body_1.title)
                });
                res.end();
            });
            break;
        default:
            console.log("hello error");
            break;
    }
});
server.listen(3333, function (err) {
    if (err)
        throw err;
});
