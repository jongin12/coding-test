const http = require("http");
const qs = require("querystring");
const fs2 = require("fs");

const getRouter = require("./src/get-router");
const domMaker = require("./src/dom-maker");

interface body {
  title?:String;
  description?:String;
  time?:String;
}

const server = http.createServer((req, res) => {
  const getMethod = req.method;
  switch (getMethod) {
    case "GET":
      const getUrl = req.url;
      if (getUrl !== "/favicon.ico") {
        // * getRouter 출력결과 두번이 일어나는 것을 확인함
        // * 슬래쉬, 파비콘 두개라 두번 트랜잭션이 발생
        // * if 제어로 간단하게 해결할 수 있게 될 것
        // * /favicon.ico는 무시하게끔 만들던지, 파비콘 하나 설정해주면 될듯
        // ! /favicon.ico 요청은 무시하도록 설정함.
        // console.log(process.memoryUsage());
        if (getUrl.endsWith(".css")) {
          let css = fs2.readFileSync('.'+getUrl, "utf8");
          res.writeHead(200, { "Content-Type": "text/css" });
          res.end(css);
        } else if (getUrl.startsWith("/list/")) {
          getRouter(getUrl);
          let number = getUrl.split("/")[2];
          res.writeHead(200, { "Content-Type": "text/html" });
          res.write(domMaker("list", number));
          res.end();
        } else if (getUrl.startsWith("/posting")) {
          getRouter(getUrl);
          let str = getUrl.split("/")[2];
          res.writeHead(200, { "Content-Type": "text/html" });
          res.write(domMaker("posting", str));
          res.end();
        } else if (getUrl.startsWith("/post/")) {
          getRouter(getUrl);
          let str = getUrl.split("/")[2];
          res.writeHead(200, { "Content-Type": "text/html" });
          res.write(domMaker("post", str));
          res.end();
        } else {
          res.writeHead(404, { "Content-Type": "text/html" });
          res.write("404 error");
          res.end();
        }
      }
      break;
    case "POST":
      // console.log("hello post");
      let body:any = '';
      req.on("data", (data) => {
        body += data;
      });
      //포스트 요청이 오면 데이터 받기,
      req.on("end", () => {
        body = qs.parse(body);
        body.time = new Date()
        // 받은 데이터를 객체로 바꾸고 time추가
        const dataBuffer = fs2.readFileSync('data.json')
        const dataJSON = dataBuffer.toString()
        const data = JSON.parse(dataJSON)
        // json파일 가져와서 객체로 변경
        data.push(body)
        //가져온 파일에 body 추가
        const bodyJson = JSON.stringify(data)
        fs2.writeFileSync('data.json',bodyJson)
        // 데이터가 추가된 객체로 다시 json파일 생성
        res.writeHead(302, {
          Location: `http://127.0.0.1:3333/post/${body.title}`,
        });
        res.end();
      });
      break;
    default:
      console.log("hello error");
      break;
  }
});

server.listen(3333, (err) => {
  if (err) throw err;
});
