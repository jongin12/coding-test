const fs = require("fs");

const textDir = () => {
  let text = "";
  let data = fs.readdirSync("./content/text");
  data.map((fileName) => {
    text += `
    <a href=${fileName}>
      <p>${fileName}</p>
    </a>
    `;
  });
  return text;
};
// * text파일 목록

const dirArr = () => {
  let data = fs.readdirSync("./content/text");
  data = data.map((fileName) => {
    return "/" + fileName;
  });
  return data;
};
// * text파일 목록 배열

const file = (fileName) => {
  // console.log(fileName);
  let text = fs.readFileSync(fileName, "utf8");
  return text;
};
// * 파일 불러오기

module.exports = function (url) {
  let data = dirArr();
  let html = "<!DOCTYPE html>";
  html += file("./head.txt");
  html += file("./content/header.txt");
  html += file("./content/main.txt");
  html += textDir();
  if (data.includes(url)) {
    html += "<h2>" + file(`./content/text${url}`) + "</h2>";
  } else {
    html += "<h2>내용이 없습니다</h2>";
  }
  html += file("./content/footer.txt");
  return html;
  // html 파일 만들기
};
